package ca.qc.test.performance;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class FileSearch {
    //I visited these links:
    //https://mkyong.com/java/search-directories-recursively-for-file-in-java/
    //https://stackoverflow.com/questions/5487473/how-to-create-an-infinite-loop-in-windows-batch-file

    private String fileNameToSearch;
    private boolean stop = false;
    private final List<String> result = new ArrayList<>();

    public String getFileNameToSearch() {
        return fileNameToSearch;
    }

    public void setFileNameToSearch(String fileNameToSearch) {
        this.fileNameToSearch = fileNameToSearch;
    }

    public List<String> getResult() {
        return result;
    }

    public FileSearch(String reponse) throws IOException {
        searchDirectory(new File(reponse), "idea64.exe");

        int count = getResult().size();
        if (count == 0) {
            System.out.println("\nNo result found!");
        } else {
            if (count == 1) {
                System.out.println("Path found!");
                System.out.println(Path.of(getResult().get(0)));
            } else
                System.out.println("You have 2 options...");
        }
    }

    public void searchDirectory(File directory, String fileNameToSearch) {
        setFileNameToSearch(fileNameToSearch);
        if (directory.isDirectory()) {
            search(directory);
        } else {
            System.out.println(directory.getAbsoluteFile() + " is not a directory!");
        }
    }

    private void search(File file) {
        if (file.isDirectory() && !stop) {
            //do you have permission to read this directory?
            try {
                if (file.canRead() && !stop) {
                    for (File temp : Objects.requireNonNull(file.listFiles())) {
                        if (temp.isDirectory() && !stop) {
                            search(temp);
                        } else {
                            if (getFileNameToSearch().equals(temp.getName().toLowerCase())) {
                                result.add(temp.getAbsoluteFile().toString());
                                stop = true;
                                break;
                            }
                        }
                    }
                } else {
                    System.out.println(file.getAbsoluteFile() + "Permission Denied");
                }
            } catch (NullPointerException ignored) {

            }
        }
    }
}
